﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_02_Task_05
{
    internal class Product
    {
        public int ID;
        public string Name;
        public double Price;
        public string Category;
        public string Brand;
        public string Country;

    }
    class Program1
    {
        public List<Product> products = new List<Product>();

        public void AddProduct()
        {
            Product p = new Product();

            Console.Write("Enter ID: ");
            p.ID = int.Parse(Console.ReadLine());

            Console.Write("Enter Name: ");
            p.Name = Console.ReadLine();

            Console.Write("Enter Price: ");
            p.Price = double.Parse(Console.ReadLine());

            Console.Write("Enter Category: ");
            p.Category = Console.ReadLine();

            Console.Write("Enter Brand: ");
            p.Brand = Console.ReadLine();

            Console.Write("Enter Country: ");
            p.Country = Console.ReadLine();

            products.Add(p);
        }
        public void ShowProducts()
        {
            for (int i = 0; i < products.Count; i++)
            {
                Console.WriteLine("ID: " + products[i].ID +
                                  " Name: " + products[i].Name +
                                  " Price: " + products[i].Price);
            }
        }

        public void TotalWorth()
        {
            double total = 0;

            for (int i = 0; i < products.Count; i++)
            {
                total = total + products[i].Price;
            }

            Console.WriteLine("Total Store Worth: " + total);
        }

    }

}