﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_02_Task_05
{

    internal class Program
    {
        static void Main(string[] args)
        {
            Program1 store = new Program1();
            int choice;

            do
            {
                Console.WriteLine("1 Add Product");
                Console.WriteLine("2 Show Products");
                Console.WriteLine("3 Total Worth");
                Console.WriteLine("4 Exit");

                Console.Write("Enter choice: ");
                choice = int.Parse(Console.ReadLine());
                Product product = new Product();
                if (choice == 1)
                    store.AddProduct();
                else if (choice == 2)
                    store.ShowProducts();
                else if (choice == 3)
                    store.TotalWorth();

            } while (choice != 4);
        }
    }
    
}
