﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_2_Task_04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            student s = new student();
            int choice = 0;
            while (choice <= 4)
            {
                Console.WriteLine("1 Add Student");
                Console.WriteLine("2 Show Students");
                Console.WriteLine("3 Top Student");
                Console.WriteLine("4 Exit");
                Console.WriteLine("Enter Choice.. ");
                choice = int.Parse(Console.ReadLine());
                if (choice == 1)
                {
                    s.AddStudent();
                }
                else if (choice == 2)
                {
                    s.showstudent();
                }
                else if (choice == 3)
                {
                    s.TopStudent();
                }
                else if (choice == 4)
                { 
                    Console.WriteLine("Exitingg....");
                break; }

            }

        }
    }
}
