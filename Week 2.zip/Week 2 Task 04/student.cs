﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_2_Task_04
{
    internal class student
    {
        public string name;
        public int marks1;
        public int marks2;
        public int marks3;

        //aggregate calculator
        public double aggregate()
        {
            return (marks1+marks2+ marks3)/3.0;
        }
    
   
    
        public List<student> students = new List<student>();

        public void AddStudent()
        {
            student s = new student();
            Console.WriteLine("Enter Name: ");
            s.name = Console.ReadLine();
            Console.WriteLine("Enter Marks 1: ");
            s.marks1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Marks 2: ");
            s.marks2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Marks 3: ");
            s.marks3 = int.Parse(Console.ReadLine());
           students.Add(s);
        }

        public void showstudent()
        {
            for (int i = 0; i < students.Count; i++)
            {
                Console.WriteLine("Name: " + students[i].name + "Aggergate: " + students[i].aggregate());
            }
        }
        public void TopStudent()
        {
            int topIndex = 0;

            for (int i = 1; i < students.Count; i++)
            {
                if (students[i].aggregate() > students[topIndex].aggregate())
                {
                    topIndex = i;
                }
            }
            Console.WriteLine("Top Student: "+ students[topIndex].name);
        }
    }
}
