﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_2_Task_02
{
    internal class Calculator
    {
        public float num1;
        public float num2;


        public Calculator(float a, float b)
        {
            num1 = a;
            num2 = b;
        }
        public float ADD ()
        {
            return num1 + num2;
        }
        // Subtraction Function
        public float Subtraction ()
        {
            return num1 - num2;
        }

        // Product Function
        public float Product()
        {
            return num1 * num2;
        }

        // Division Function
        public float Division ()
        {
            return num1 / num2;
        }
    }
}
