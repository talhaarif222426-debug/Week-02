﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Week_2_Task_02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float num1;
            Console.WriteLine("Enter A Digit: ");
             num1= float.Parse(Console.ReadLine());
            float num2;
            Console.WriteLine("Enter A Digit: ");
            num2 = float.Parse(Console.ReadLine());

            Calculator c = new Calculator(num1, num2);
            Console.WriteLine("Addition: " + c.ADD());
            Console.WriteLine("Subtraction: " + c.Subtraction());
            Console.WriteLine("Product: " + c.Product());
            Console.WriteLine("Division: " + c.Division());
        }
    }
}
