﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_02_Task_03
{
    internal class ATM
    {
        public double balance;
        public List<string> transactions = new List<string>();


        public ATM(double initialbalance)
        {
            balance = initialbalance;
            transactions.Add("Account opened with: " + initialbalance);
        }
        public void deposit(double amount)
        {
            balance = balance + amount;
            transactions.Add("Deposited: " + amount);
        }
        public void withdraw(double amount)
        {
            if (amount <= balance)
            {
                balance = balance - amount;
                transactions.Add("Withdrawn Amount: " + amount);
            }
            else
            {
                Console.WriteLine("Insufficent Balance.");
            }
        }
        public void checkBalnce()
        {
            Console.WriteLine("Your Current Balance is: " + balance);
        }
        public void transactionHistory()
        {
            Console.WriteLine("Transaction History");
            foreach (var transaction in transactions)
            {
                Console.WriteLine(transaction);
            }
        }
    }
}
