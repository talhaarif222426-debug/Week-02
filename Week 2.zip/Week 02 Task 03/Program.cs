﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_02_Task_03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ATM atm = new ATM(10000);
            atm.deposit(5000);
            atm.withdraw(7000);
            atm.checkBalnce();
            atm.transactionHistory();
        }
    }
}
